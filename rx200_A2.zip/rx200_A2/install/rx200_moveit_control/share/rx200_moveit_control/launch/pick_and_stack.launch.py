from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution, LaunchConfiguration
from launch_ros.substitutions import FindPackageShare
from launch.substitutions import Command
import os

def generate_launch_description():
    ld = LaunchDescription()
    
    declare_randomize = DeclareLaunchArgument(
        'randomize_order',
        default_value='false',
        description='Randomize cube stacking order (true/false)'
    )
    
    current_workspace = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    rx200_urdf = os.path.join(current_workspace, 'src', 'rx200_description', 'urdf', 'rx200.urdf.xacro')
    
    robot_description = Command([
        'xacro ', rx200_urdf,
        ' robot_name:=rx200',
        ' use_world_frame:=true'
    ])
    
    moveit_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare('interbotix_xsarm_moveit'),
                'launch',
                'xsarm_moveit.launch.py'
            ])
        ),
        launch_arguments={
            'robot_model': 'rx200',
            'use_world_frame': 'true',
        }.items()
    )
    
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_description}]
    )
    
    vision_detector = Node(
        package='rx200_moveit_control',
        executable='rx200_vision_detector',
        output='screen',
        parameters=[
            {'detection_mode': 'multi'},
            {'color_topic': '/camera/camera/color/image_raw'},
            {'depth_topic': '/camera/camera/depth/image_rect_raw'},
            {'focal_length': 380.0},
            {'min_object_area': 500},
            {'max_depth': 2.0}
        ]
    )
    
    pick_and_stack = Node(
        package='rx200_moveit_control',
        executable='rx200_pick_and_stack',
        output='screen',
        parameters=[
            {'stack_location_x': -0.20},
            {'stack_location_y': -0.20},
            {'stack_base_z': 0.15},
            {'cube_height': 0.05},
            {'pre_pick_height': 0.15},
            {'ready_pose_x': 0.3},
            {'ready_pose_y': 0.0},
            {'ready_pose_z': 0.35},
            {'randomize_order': LaunchConfiguration('randomize_order')}
        ]
    )
    
    ld.add_action(declare_randomize)
    ld.add_action(robot_state_publisher)
    ld.add_action(moveit_launch)
    ld.add_action(vision_detector)
    ld.add_action(pick_and_stack)
    
    return ld
