from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription, ExecuteProcess
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare
from launch.substitutions import Command
import os

def generate_launch_description():
    ld = LaunchDescription()
    
    rx200_description_share = FindPackageShare('rx200_description')
    rx200_urdf = PathJoinSubstitution([rx200_description_share, 'urdf', 'rx200.urdf.xacro'])
    
    robot_description = Command([
        'xacro ', rx200_urdf,
        ' robot_name:=rx200',
        ' use_world_frame:=true'
    ])
    
    perception_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare('interbotix_xsarm_perception'),
                'launch',
                'xsarm_perception.launch.py'
            ])
        ),
        launch_arguments={
            'robot_model': 'rx200',
            'use_pointcloud_tuner_gui': 'false',
            'use_armtag_tuner_gui': 'false',
            'use_armtag': 'false',
            'use_world_frame': 'true',
        }.items()
    )
    
    moveit_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare('interbotix_xsarm_moveit'),
                'launch',
                'xsarm_moveit.launch.py'
            ])
        ),
        launch_arguments={
            'robot_model': 'rx200',
            'use_world_frame': 'true',
        }.items()
    )
    
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_description}]
    )
    
    vision_detector = ExecuteProcess(
        cmd=[
            'python3', '-m', 'rx200_moveit_control.rx200_vision_detector',
            '--ros-args',
            '-p', 'color_topic:=/camera/camera/color/image_raw',
            '-p', 'depth_topic:=/camera/camera/depth/image_rect_raw'
        ],
        output='screen'
    )
    
    pick_script = ExecuteProcess(
        cmd=['python3', '-m', 'rx200_moveit_control.rx200_pick_by_vision'],
        output='screen'
    )
    
    ld.add_action(robot_state_publisher)
    ld.add_action(perception_launch)
    ld.add_action(moveit_launch)
    ld.add_action(vision_detector)
    ld.add_action(pick_script)
    
    return ld
