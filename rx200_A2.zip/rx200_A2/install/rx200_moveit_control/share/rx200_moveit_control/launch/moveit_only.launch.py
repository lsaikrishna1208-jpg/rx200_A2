from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare
from launch.substitutions import Command

def generate_launch_description():
    ld = LaunchDescription()
    
    rx200_description_share = FindPackageShare('rx200_description')
    rx200_urdf = PathJoinSubstitution([rx200_description_share, 'urdf', 'rx200.urdf.xacro'])
    
    robot_description = Command([
        'xacro ', rx200_urdf,
        ' robot_name:=rx200',
        ' use_world_frame:=true'
    ])
    
    moveit_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare('interbotix_xsarm_moveit'),
                'launch',
                'xsarm_moveit.launch.py'
            ])
        ),
        launch_arguments={
            'robot_model': 'rx200',
            'use_world_frame': 'true',
        }.items()
    )
    
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_description}]
    )
    
    ld.add_action(robot_state_publisher)
    ld.add_action(moveit_launch)
    
    return ld
