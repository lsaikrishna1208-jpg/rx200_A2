from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    dc = DeclareLaunchArgument(
        'default_gr_state',
        default_value='true',
        description='Initial gripper state (true=open, false=closed)'
    )

    moveit_control = Node(
        package='rx200_moveit_control',
        executable='rx200_pick_by_vision',
        output='screen',
        parameters=[{'start_state_gripper': LaunchConfiguration('default_gr_state')}]
    )

    ld = LaunchDescription()
    ld.add_action(dc)
    ld.add_action(moveit_control)

    return ld
    