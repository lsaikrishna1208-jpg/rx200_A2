# RX200 Vision-Based Object Picking Pipeline

## Overview
This system uses OpenCV to detect colored objects via RGB-D camera and automatically commands the RX200 arm to pick them using MoveIt.

## Architecture

```
Camera Input (RGB-D)
     ↓
rx200_vision_detector.py
  (OpenCV detection)
     ↓
/rx200/target_object_pose
     ↓
rx200_pick_by_vision.py
  (MoveIt planning)
     ↓
Robot Arm Motion
```

## How It Works

### 1. Vision Detection (`rx200_vision_detector.py`)
- Subscribes to camera topics:
  - `/camera/color/image_raw` - RGB image
  - `/camera/aligned_depth_to_color/image_raw` - Depth map
- Detects colored objects using HSV color ranges:
  - **Blue**: HSV(100-130, 100-255, 100-255)
  - **Green**: HSV(40-90, 50-255, 50-255)
  - **Yellow**: HSV(15-35, 100-255, 100-255)
- Converts pixel coordinates to 3D world coordinates using camera intrinsics
- Publishes object pose to `/rx200/target_object_pose`

**Configurable Parameters:**
```yaml
focal_length: 380.0         # Camera focal length (pixels)
min_object_area: 500        # Minimum contour area (pixels)
max_depth: 2.0              # Maximum depth distance (meters)
color_topic: /camera/color/image_raw
depth_topic: /camera/aligned_depth_to_color/image_raw
```

### 2. Pick Execution (`rx200_pick_by_vision.py`)
- Subscribes to `/rx200/target_object_pose`
- Executes 4-step pick sequence:
  1. **Pre-pick**: Move to object location + 15cm above (default)
  2. **Pick**: Move down to object location
  3. **Grasp**: Close gripper
  4. **Lift**: Move back to pre-pick height
- Places object at configurable location

**Configurable Parameters:**
```yaml
pre_pick_height: 0.15           # Offset above object (meters)
place_location_x: -0.20         # Place X coordinate (meters)
place_location_y: -0.20         # Place Y coordinate (meters)
place_location_z: 0.15          # Place Z coordinate (meters)
ready_pose_x: 0.3               # Ready pose X (meters)
ready_pose_y: 0.0               # Ready pose Y (meters)
ready_pose_z: 0.35              # Ready pose Z (meters)
```

## Launch

### Full Pipeline (Recommended)
Starts everything: robot state publisher, MoveIt, perception, vision detector, and pick script.

```bash
source /home/master26/interbotix_ws/install/setup.bash
source install/setup.bash

ros2 launch rx200_moveit_control unified_pick_and_place.launch.py \
  robot_model:=rx200 \
  hardware_type:=fake
```

**Arguments:**
- `robot_model`: Robot model (default: rx200)
- `hardware_type`: 
  - `fake` - No hardware, simulation only
  - `actual` - Real hardware
  - `gz_classic` - Gazebo Classic simulation

### Individual Components

**Vision Detector Only:**
```bash
ros2 run rx200_moveit_control rx200_vision_detector \
  --ros-args \
  -p focal_length:=380.0 \
  -p min_object_area:=500 \
  -p max_depth:=2.0
```

**Pick Script Only:**
```bash
ros2 run rx200_moveit_control rx200_pick_by_vision \
  --ros-args \
  -p pre_pick_height:=0.15 \
  -p place_location_x:=-0.20 \
  -p place_location_y:=-0.20 \
  -p place_location_z:=0.15
```

## Testing

### Check if Object is Detected
```bash
ros2 topic echo /rx200/target_object_pose
```

Expected output (when object detected):
```
header:
  stamp: ...
  frame_id: camera_depth_optical_frame
pose:
  position:
    x: 0.2345
    y: -0.1234
    z: 0.5678
  orientation:
    x: 0.0
    y: 0.0
    z: 0.0
    w: 1.0
```

### View Debug Logs
```bash
ros2 run rx200_moveit_control rx200_vision_detector --log-level debug
```

## Troubleshooting

### Object Not Detected
1. **Check camera feed:**
   ```bash
   ros2 run image_view image_view image:=/camera/color/image_raw
   ros2 run image_view disparity_view image:=/camera/aligned_depth_to_color/image_raw
   ```

2. **Adjust color thresholds** in `rx200_vision_detector.py`:
   - Print HSV values of your object
   - Update lower/upper HSV ranges

3. **Increase minimum area threshold:**
   ```bash
   -p min_object_area:=200
   ```

### Robot Not Moving
1. **Check if MoveIt started:**
   ```bash
   ros2 topic list | grep move_group
   ```

2. **Verify object pose frame:**
   - Object pose must be in base_link frame
   - Current: `camera_depth_optical_frame`
   - Need transform to `rx200/base_link`

3. **Check gripper control:**
   ```bash
   ros2 service call /set_gripper std_srvs/SetBool "{data: true}"
   ```

## Coordinate Frames

- **camera_depth_optical_frame**: Camera optical center
- **rx200/base_link**: Robot base
- **rx200/wrist_link**: End effector
- **rx200/ee_gripper_link**: Gripper tool frame

## Camera Calibration

To recalibrate camera focal length:
```bash
ros2 run camera_calibration cameracalibrator.py --size 8x6 --square 0.03
```

## Performance Notes

- Detection runs at camera frame rate (~30 Hz)
- Pick sequence: ~10-20 seconds total
- Only picks when object detected (not continuous)
