# Inside ~/rx200_ws/src/rx200_description/launch/display.launch.py
from launch.actions import DeclareLaunchArgument

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.actions import Node as Node
from launch.substitutions import Command
from launch_ros.substitutions import Command 

def generate_launch_description():

    # 1. Define the package path and XACRO file location
    pkg_share = get_package_share_directory('rx200_description')
    default_xacro_path = os.path.join(pkg_share, 'urdf', 'ros2b_urdf_macro.xacro')

    declare_xacro_path = DeclareLaunchArgument(
        name='xacro_path',
        default_value=default_xacro_path,
        description='Path to the XACRO file'
    )
    # 2. Configure the Robot State Publisher
    #robot_description =  LaunchConfiguration('robot_description')
    robot_description_content= Command(['xacro ', LaunchConfiguration('xacro_path')])
    
    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher_node',
        output='screen',
        parameters=[{'robot_description': robot_description_content}]
    )

     #3. Configure the Joint State Publisher GUI (for manual control)
    joint_state_publisher_gui_node = Node(
        package='joint_state_publisher_gui',
        executable='joint_state_publisher_gui',
        name='joint_state_publisher_gui'
    )

    # 4. Configure RViz 2
    rviz_config_path = os.path.join(pkg_share, 'rviz', 'config_file.rviz') 
    # You don't have this file yet, but RViz will launch with default config.

    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz_node',
        output='screen'
    )

    # Return the launch description
    return LaunchDescription([
        # Allow the user to specify the xacro file path from the command line
        DeclareLaunchArgument(
            name='xacro_path',
            default_value=default_xacro_path,
            description='Path to the XACRO file'
        ),
        declare_xacro_path,
        robot_state_publisher_node,
        joint_state_publisher_gui_node,
        rviz_node
    ])