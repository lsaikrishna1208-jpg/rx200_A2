#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, PointStamped
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from std_msgs.msg import String
import cv2
import numpy as np
import json

class RX200VisionDetector(Node):
    def __init__(self):
        super().__init__('rx200_vision_detector')
        
        self.declare_parameter('focal_length', 380.0)
        self.declare_parameter('min_object_area', 500)
        self.declare_parameter('max_depth', 2.0)
        self.declare_parameter('color_topic', '/camera/camera/color/image_raw')
        self.declare_parameter('depth_topic', '/camera/camera/depth/image_rect_raw')
        self.declare_parameter('detection_mode', 'multi')
        
        self.bridge = CvBridge()
        self.base_link = 'rx200/base_link'
        
        self.focal_length = self.get_parameter('focal_length').value
        self.min_object_area = self.get_parameter('min_object_area').value
        self.max_depth = self.get_parameter('max_depth').value
        self.detection_mode = self.get_parameter('detection_mode').value
        color_topic = self.get_parameter('color_topic').value
        depth_topic = self.get_parameter('depth_topic').value
        
        self.color_sub = self.create_subscription(
            Image,
            color_topic,
            self.color_image_callback,
            10
        )
        
        self.depth_sub = self.create_subscription(
            Image,
            depth_topic,
            self.depth_image_callback,
            10
        )
        
        self.object_pose_pub = self.create_publisher(
            PoseStamped,
            '/rx200/target_object_pose',
            10
        )
        
        self.cubes_poses_pub = self.create_publisher(
            String,
            '/rx200/detected_cubes',
            10
        )
        
        self.color_image = None
        self.depth_image = None
        self.object_detected = False
        self.detection_counter = 0
        
        self.color_ranges = {
            'blue': {
                'lower': np.array([100, 100, 100]),
                'upper': np.array([130, 255, 255])
            },
            'green': {
                'lower': np.array([40, 50, 50]),
                'upper': np.array([90, 255, 255])
            },
            'yellow': {
                'lower': np.array([15, 100, 100]),
                'upper': np.array([35, 255, 255])
            }
        }
        
        self.get_logger().info(f'Vision detector initialized in {self.detection_mode} mode. Focal length: {self.focal_length}, Min area: {self.min_object_area}')
    
    def color_image_callback(self, msg):
        try:
            self.color_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='passthrough')
            if len(self.color_image.shape) == 2:
                self.color_image = cv2.cvtColor(self.color_image, cv2.COLOR_GRAY2RGB)
            elif self.color_image.shape[2] == 4:
                self.color_image = cv2.cvtColor(self.color_image, cv2.COLOR_BGRA2RGB)
            elif self.color_image.shape[2] == 3:
                if msg.encoding in ['bgra8', 'bgr8']:
                    self.color_image = cv2.cvtColor(self.color_image, cv2.COLOR_BGR2RGB)
            self.detect_objects()
        except Exception as e:
            self.get_logger().error(f'Error processing color image: {e}')
    
    def depth_image_callback(self, msg):
        try:
            self.depth_image = self.bridge.imgmsg_to_cv2(msg, 'passthrough')
        except Exception as e:
            self.get_logger().error(f'Error processing depth image: {e}')
    
    def detect_objects(self):
        if self.color_image is None or self.depth_image is None:
            return
        
        if self.detection_mode == 'single' and self.object_detected:
            return
        
        hsv = cv2.cvtColor(self.color_image, cv2.COLOR_RGB2HSV)
        
        mask_blue = cv2.inRange(hsv, self.color_ranges['blue']['lower'], self.color_ranges['blue']['upper'])
        mask_green = cv2.inRange(hsv, self.color_ranges['green']['lower'], self.color_ranges['green']['upper'])
        mask_yellow = cv2.inRange(hsv, self.color_ranges['yellow']['lower'], self.color_ranges['yellow']['upper'])
        
        masks = {
            'blue': mask_blue,
            'green': mask_green,
            'yellow': mask_yellow
        }
        
        detected_cubes = []
        
        for color_name, mask in masks.items():
            contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
            
            for contour in contours:
                area = cv2.contourArea(contour)
                
                if area < self.min_object_area:
                    continue
                
                M = cv2.moments(contour)
                if M['m00'] == 0:
                    continue
                
                cx = int(M['m10'] / M['m00'])
                cy = int(M['m01'] / M['m00'])
                
                if cy < 0 or cy >= self.depth_image.shape[0] or cx < 0 or cx >= self.depth_image.shape[1]:
                    continue
                
                depth_value = self.depth_image[cy, cx] / 1000.0
                
                if depth_value == 0 or depth_value > self.max_depth:
                    continue
                
                principal_point_x = self.color_image.shape[1] / 2
                principal_point_y = self.color_image.shape[0] / 2
                
                x = (cx - principal_point_x) * depth_value / self.focal_length
                y = (cy - principal_point_y) * depth_value / self.focal_length
                z = depth_value
                
                detected_cubes.append({
                    'color': color_name,
                    'x': float(x),
                    'y': float(y),
                    'z': float(z),
                    'area': float(area),
                    'pixel_x': int(cx),
                    'pixel_y': int(cy)
                })
        
        if len(detected_cubes) == 0:
            return
        
        if self.detection_mode == 'single':
            largest_cube = max(detected_cubes, key=lambda c: c['area'])
            self.publish_single_cube(largest_cube)
            self.object_detected = True
        else:
            self.publish_all_cubes(detected_cubes)
    
    def publish_single_cube(self, cube):
        pose = PoseStamped()
        pose.header.frame_id = 'camera_depth_optical_frame'
        pose.header.stamp = self.get_clock().now().to_msg()
        pose.pose.position.x = cube['x']
        pose.pose.position.y = cube['y']
        pose.pose.position.z = cube['z']
        pose.pose.orientation.w = 1.0
        
        self.object_pose_pub.publish(pose)
        self.get_logger().info(f'✓ {cube["color"].upper()} cube detected:')
        self.get_logger().info(f'  Position: ({cube["x"]:.4f}, {cube["y"]:.4f}, {cube["z"]:.4f}) m')
        self.get_logger().info(f'  Area: {cube["area"]:.0f} pixels')
    
    def publish_all_cubes(self, cubes):
        self.detection_counter += 1
        if self.detection_counter % 5 != 0:
            return
        
        cubes_json = json.dumps(cubes)
        msg = String()
        msg.data = cubes_json
        self.cubes_poses_pub.publish(msg)
        
        self.get_logger().info(f'✓ Detected {len(cubes)} cubes:')
        for cube in cubes:
            self.get_logger().info(f'  {cube["color"].upper()}: ({cube["x"]:.4f}, {cube["y"]:.4f}, {cube["z"]:.4f})')

def main(args=None):
    rclpy.init(args=args)
    node = RX200VisionDetector()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        rclpy.shutdown()

if __name__ == '__main__':
    main()
