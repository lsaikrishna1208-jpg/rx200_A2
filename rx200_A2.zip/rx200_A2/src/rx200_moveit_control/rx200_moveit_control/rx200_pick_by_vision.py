#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from moveit_msgs.action import MoveGroup
from moveit_msgs.msg import MotionPlanRequest, Constraints, PositionConstraint, OrientationConstraint, JointConstraint
from shape_msgs.msg import SolidPrimitive
from geometry_msgs.msg import PoseStamped, Quaternion
from rclpy.subscription import Subscription
import time
import sys

class PickByVisionClient(Node):
    def __init__(self):
        super().__init__('pick_by_vision_client')

        self.declare_parameter('pre_pick_height', 0.15)
        self.declare_parameter('place_location_x', -0.20)
        self.declare_parameter('place_location_y', -0.20)
        self.declare_parameter('place_location_z', 0.15)
        self.declare_parameter('ready_pose_x', 0.3)
        self.declare_parameter('ready_pose_y', 0.0)
        self.declare_parameter('ready_pose_z', 0.35)

        self.pre_pick_height = self.get_parameter('pre_pick_height').value
        self.place_x = self.get_parameter('place_location_x').value
        self.place_y = self.get_parameter('place_location_y').value
        self.place_z = self.get_parameter('place_location_z').value
        self.ready_x = self.get_parameter('ready_pose_x').value
        self.ready_y = self.get_parameter('ready_pose_y').value
        self.ready_z = self.get_parameter('ready_pose_z').value

        self._arm_client = ActionClient(self, MoveGroup, '/move_group')
        while not self._arm_client.wait_for_server(1.0):
            self.get_logger().warning('Waiting for MoveIt Action Server on /move_group...')
        
        self.group_name_arm = 'interbotix_arm'
        self.ee_link = 'rx200/ee_gripper_link'
        self.base_link = 'rx200/base_link'
        self.gripper_joint = 'left_finger'
        self.group_name_gripper = 'interbotix_gripper'
        self.motion_done = False
        self.motion_result = None

        # 2. Vision Subscriber
        self.object_pose_sub: Subscription = self.create_subscription(
            PoseStamped,
            '/rx200/target_object_pose',
            self.object_pose_callback,
            10
        )
        self.get_logger().info('Waiting for object pose on /rx200/target_object_pose...')

        self.get_logger().info(f'Ready pose: ({self.ready_x}, {self.ready_y}, {self.ready_z})')
        self.get_logger().info(f'Place location: ({self.place_x}, {self.place_y}, {self.place_z})')

        self.send_gr_pose(open=True)
        if not self.wait_for_motion(timeout=5.0):
            self.get_logger().error('Failed to open gripper during initialization.')
            raise RuntimeError('Gripper initialization failed')

        self.send_pose(x=self.ready_x, y=self.ready_y, z=self.ready_z)
        if not self.wait_for_motion(timeout=10.0):
            self.get_logger().error('Failed to reach ready pose during initialization.')
            raise RuntimeError('Arm initialization failed')

        self.get_logger().info('Node initialized. Ready for pick request.')

    def object_pose_callback(self, msg: PoseStamped):
        """Processes the received object pose and starts the pick sequence."""
        self.get_logger().info('='*60)
        self.get_logger().info('🎯 TARGET OBJECT DETECTED! STARTING PICK SEQUENCE')
        self.get_logger().info('='*60)
        
        self.destroy_subscription(self.object_pose_sub) 

        target_x = msg.pose.position.x
        target_y = msg.pose.position.y
        target_z = msg.pose.position.z
        
        self.get_logger().info(f'Object pose (frame: {msg.header.frame_id}):')
        self.get_logger().info(f'  X: {target_x:.4f}m, Y: {target_y:.4f}m, Z: {target_z:.4f}m') 

        pre_pick_z = target_z + self.pre_pick_height
        pick_z = target_z
        post_pick_z = pre_pick_z
        
        self.get_logger().info(f'Calculated waypoints:')
        self.get_logger().info(f'  Pre-pick Z: {pre_pick_z:.4f}m (object Z + {self.pre_pick_height}m offset)')
        self.get_logger().info(f'  Pick Z: {pick_z:.4f}m (at object)')
        self.get_logger().info(f'  Post-pick Z: {post_pick_z:.4f}m')
        self.get_logger().info('')
        
        self.get_logger().info(f'[1/4] Moving to pre-pick pose')
        self.get_logger().info(f'  Target: ({target_x:.4f}, {target_y:.4f}, {pre_pick_z:.4f})')
        self.send_pose(target_x, target_y, pre_pick_z)
        if not self.wait_for_motion(timeout=15.0):
            self.get_logger().error('Failed to reach pre-pick pose.')
            return

        self.get_logger().info(f'[2/4] Descending to pick pose')
        self.get_logger().info(f'  Target: ({target_x:.4f}, {target_y:.4f}, {pick_z:.4f})')
        self.send_pose(target_x, target_y, pick_z)
        if not self.wait_for_motion(timeout=15.0):
            self.get_logger().error('✗ Failed to reach pick pose.')
            return

        self.get_logger().info(f'[3/4] Closing gripper to grasp object')
        self.send_gr_pose(open=False)
        if self.wait_for_motion(timeout=5.0):
            self.get_logger().info('  ✓ Gripper closed')
        else:
            self.get_logger().warning('  ⚠ Gripper close timed out')
        
        self.get_logger().info(f'[4/4] Moving to post-pick pose')
        self.get_logger().info(f'  Target: ({target_x:.4f}, {target_y:.4f}, {post_pick_z:.4f})')
        self.send_pose(target_x, target_y, post_pick_z)
        if not self.wait_for_motion(timeout=15.0):
            self.get_logger().error('✗ Failed to reach post-pick pose.')
            return

        self.get_logger().info('')
        self.get_logger().info('='*60)
        self.get_logger().info('✓ PICK COMPLETE! Object is grasped and lifted.')
        self.get_logger().info('='*60)
        
        self.get_logger().info(f'Moving to place location: ({self.place_x}, {self.place_y}, {self.place_z})')
        self.send_pose(x=self.place_x, y=self.place_y, z=self.place_z)
        self.wait_for_motion(timeout=15.0)

        self.get_logger().info('Releasing object...')
        self.send_gr_pose(open=True)
        self.wait_for_motion(timeout=5.0)

        self.get_logger().info('Sequence finished. Shutting down.')
        sys.exit(0)

    def send_pose(self, x, y, z, w=1.0):
        """Send a target pose for the end effector."""
        self.motion_done = False
        self.motion_result = None

        pose = PoseStamped()
        pose.header.frame_id = self.base_link
        pose.pose.position.x = x
        pose.pose.position.y = y
        pose.pose.position.z = z
        pose.pose.orientation = Quaternion(x=0.0, y=0.0, z=0.0, w=1.0)

        req = MotionPlanRequest()
        req.group_name = self.group_name_arm
        req.allowed_planning_time = 5.0
        req.num_planning_attempts = 3
        req.start_state.is_diff = True

        # Position constraint
        pc = PositionConstraint()
        pc.header.frame_id = self.base_link
        pc.link_name = self.ee_link
        sp = SolidPrimitive()
        sp.type = SolidPrimitive.SPHERE
        sp.dimensions = [0.05]
        pc.constraint_region.primitives = [sp]
        pc.constraint_region.primitive_poses = [pose.pose]
        pc.weight = 1.0

        # Orientation constraint
        oc = OrientationConstraint()
        oc.header.frame_id = self.base_link
        oc.link_name = self.ee_link
        oc.orientation = pose.pose.orientation
        oc.absolute_x_axis_tolerance = 0.5
        oc.absolute_y_axis_tolerance = 0.5
        oc.absolute_z_axis_tolerance = 0.5
        oc.weight = 1.0

        goal_constraints = Constraints()
        goal_constraints.position_constraints = [pc]
        goal_constraints.orientation_constraints = [oc]
        req.goal_constraints = [goal_constraints]

        goal = MoveGroup.Goal()
        goal.request = req
        goal.planning_options.plan_only = False
        goal.planning_options.replan = True
        goal.planning_options.look_around = False

        send_future = self._arm_client.send_goal_async(goal, feedback_callback=self._feedback_cb)
        send_future.add_done_callback(self._goal_response_cb)

    def send_gr_pose(self, open=True):
        """Move the gripper (open or close)."""
        self.motion_done = False
        self.motion_result = None

        req = MotionPlanRequest()
        req.group_name = self.group_name_gripper
        req.allowed_planning_time = 2.0
        req.num_planning_attempts = 1

        jc = JointConstraint()
        jc.joint_name = self.gripper_joint
        jc.position = 0.035 if open else 0.0
        jc.tolerance_above = 0.01
        jc.tolerance_below = 0.01
        jc.weight = 1.0

        goal_constraints = Constraints()
        goal_constraints.joint_constraints = [jc]
        req.goal_constraints = [goal_constraints]
        
        goal = MoveGroup.Goal()
        goal.request = req
        goal.planning_options.plan_only = False

        send_future = self._arm_client.send_goal_async(goal)
        send_future.add_done_callback(self._goal_response_cb)

    def _goal_response_cb(self, future):
        """Callback when goal is accepted or rejected."""
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error('MoveIt Goal rejected')
            self.motion_done = True
            self.motion_result = -1
            return
        self.get_logger().info('MoveIt Goal Accepted')
        goal_handle.get_result_async().add_done_callback(self._result_cb)

    def _feedback_cb(self, feedback_msg):
        """Callback for motion feedback."""
        state = getattr(feedback_msg.feedback, "state", "<unknown>")
        self.get_logger().info(f'[Feedback] {state}')

    def _result_cb(self, future):
        """Callback when motion completes."""
        result = future.result().result
        code = getattr(result.error_code, 'val', 'unknown')
        self.motion_result = code
        self.motion_done = True
        self.get_logger().info(f'[RESULT] error_code {code}')

    def wait_for_motion(self, timeout=10.0):
        """Wait for current motion to complete."""
        start_time = time.time()
        while rclpy.ok() and not self.motion_done:
            rclpy.spin_once(self, timeout_sec=0.1)
            if time.time() - start_time > timeout:
                self.get_logger().warning('Timeout waiting for motion result.')
                return False
        if self.motion_result != 1:
            self.get_logger().warning(f'Motion failed with error code: {self.motion_result}')
            return False
        return True


def main(args=None):
    rclpy.init(args=args)
    try:
        node = PickByVisionClient()
        rclpy.spin(node)
    except (SystemExit, RuntimeError) as e:
        if isinstance(e, RuntimeError):
            print(f'Error: {e}', file=sys.stderr)
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()