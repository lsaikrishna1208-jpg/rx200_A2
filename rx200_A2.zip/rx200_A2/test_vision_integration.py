#!/usr/bin/env python3
"""
Test script to verify vision detection → MoveIt pick integration
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from moveit_msgs.action import MoveGroup
from rclpy.action import ActionClient
import time
import sys


class VisionIntegrationTest(Node):
    def __init__(self):
        super().__init__('vision_integration_test')
        
        self.pose_received = False
        self.pose_data = None
        
        self.pose_sub = self.create_subscription(
            PoseStamped,
            '/rx200/target_object_pose',
            self.pose_callback,
            10
        )
        
        self.move_client = ActionClient(self, MoveGroup, '/move_group')
        
        self.get_logger().info('Vision Integration Test Started')
        self.get_logger().info('Waiting for:')
        self.get_logger().info('  1. Camera topics to be published')
        self.get_logger().info('  2. Object detection via OpenCV')
        self.get_logger().info('  3. Pose published to /rx200/target_object_pose')
        self.get_logger().info('')
        self.get_logger().info('Place a colored object (blue, green, or yellow) in front of the camera...')
    
    def pose_callback(self, msg: PoseStamped):
        self.pose_received = True
        self.pose_data = msg
        
        self.get_logger().info('')
        self.get_logger().info('='*70)
        self.get_logger().info('✓ OBJECT DETECTED!')
        self.get_logger().info('='*70)
        self.get_logger().info(f'Frame: {msg.header.frame_id}')
        self.get_logger().info(f'Timestamp: {msg.header.stamp.sec}.{msg.header.stamp.nanosec}')
        self.get_logger().info(f'Position:')
        self.get_logger().info(f'  X: {msg.pose.position.x:.4f} m')
        self.get_logger().info(f'  Y: {msg.pose.position.y:.4f} m')
        self.get_logger().info(f'  Z: {msg.pose.position.z:.4f} m')
        self.get_logger().info(f'Orientation:')
        self.get_logger().info(f'  W: {msg.pose.orientation.w:.4f}')
        self.get_logger().info('')
        self.get_logger().info('This pose will be sent to MoveIt for picking!')
        self.get_logger().info('Pipeline status: ✓ WORKING')
        self.get_logger().info('='*70)


def main():
    rclpy.init()
    node = VisionIntegrationTest()
    
    timeout = 30
    start = time.time()
    
    try:
        while not node.pose_received and (time.time() - start) < timeout:
            rclpy.spin_once(node, timeout_sec=0.5)
        
        if node.pose_received:
            node.get_logger().info('✓ Vision → MoveIt integration test PASSED')
            sys.exit(0)
        else:
            node.get_logger().error(f'✗ No object detected after {timeout}s')
            node.get_logger().error('  Check:')
            node.get_logger().error('    - Camera is publishing to /camera/color/image_raw')
            node.get_logger().error('    - Depth is publishing to /camera/aligned_depth_to_color/image_raw')
            node.get_logger().error('    - Object is blue, green, or yellow')
            node.get_logger().error('    - Object is visible to camera')
            sys.exit(1)
    except KeyboardInterrupt:
        node.get_logger().info('Test interrupted')
        sys.exit(0)
    finally:
        rclpy.shutdown()


if __name__ == '__main__':
    main()
